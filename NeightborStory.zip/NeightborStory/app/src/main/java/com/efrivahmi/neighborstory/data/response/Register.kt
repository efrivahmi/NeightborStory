package com.efrivahmi.neighborstory.data.response

class Register (
    val error: Boolean,
    val message: String
)
