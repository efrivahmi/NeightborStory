package com.efrivahmi.neighborstory.data.response

data class AddStory(
    val error: Boolean,
    val message: String
    )
