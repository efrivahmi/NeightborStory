package com.efrivahmi.neighborstory.ui.register

import android.content.Intent
import android.os.Bundle
import android.text.method.HideReturnsTransformationMethod
import android.text.method.PasswordTransformationMethod
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.efrivahmi.neighborstory.databinding.ActivityRegisterBinding
import com.efrivahmi.neighborstory.ui.welcome.WelcomeNeighborActivity
import com.efrivahmi.neighborstory.utils.NeighborFactory

class RegisterActivity : AppCompatActivity() {
    private lateinit var binding: ActivityRegisterBinding
    private lateinit var factory: NeighborFactory
    private val registerViewModel: RegisterViewModel by viewModels { factory }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(binding.root)

        factory = NeighborFactory.getInstance(this)

        supportActionBar?.title = barTitle
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        clickButton()
    }

    private fun clickButton() {
        binding.btRegister.setOnClickListener {
            val name = binding.tiName.text.toString().trim()
            val email = binding.tiEmail.text.toString().trim()
            val password = binding.tiPass.text.toString().trim()

            if (name.isEmpty() || email.isEmpty() || password.isEmpty() || !isValidEmail(email)) {
                binding.tiName.error = FILL_NAME
                binding.tiEmail.error = FILL_EMAIL
                binding.tiPass.error = FILL_PASSWORD
            } else {
                showLoading()
                uploadData(name, email, password)
                showToast()
            }
        }

        binding.seePassword.setOnClickListener {
            if (binding.seePassword.isChecked) {
                binding.tiPass.transformationMethod = HideReturnsTransformationMethod.getInstance()
            } else {
                binding.tiPass.transformationMethod = PasswordTransformationMethod.getInstance()
            }
        }
    }

    private fun showLoading() {
        registerViewModel.isLoading.observe(this) {
            binding.progressBar2.visibility = if (it) View.VISIBLE else View.GONE
        }
    }

    private fun showToast() {
        registerViewModel.toast.observe(this) {
            it.getContentIfNotHandled()?.let { toastText ->
                Toast.makeText(
                    this, toastText, Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    private fun uploadData(name: String, email: String, password: String) {
        registerViewModel.uploadRegisData(name, email, password)
        registerViewModel.regis.observe(this) { response ->
            if (!response.error) {
                startActivity(Intent(this, WelcomeNeighborActivity::class.java))
                finish()
            }
        }
    }

    private fun isValidEmail(email: CharSequence): Boolean {
        return android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()
    }

    companion object {
        private const val FILL_NAME = "Have to fill your name"
        private const val FILL_PASSWORD = "Have to fill password first"
        private const val FILL_EMAIL = "Have to fill email first"
        private const val barTitle = "Create Account"
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return super.onSupportNavigateUp()
    }
}