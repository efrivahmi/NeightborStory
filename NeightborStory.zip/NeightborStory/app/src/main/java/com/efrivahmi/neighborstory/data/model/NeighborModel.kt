package com.efrivahmi.neighborstory.data.model

data class NeighborModel(
    val name: String,
    val token: String,
    val isLogin: Boolean
)
