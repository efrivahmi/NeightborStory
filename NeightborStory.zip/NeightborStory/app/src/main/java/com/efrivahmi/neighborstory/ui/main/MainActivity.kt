package com.efrivahmi.neighborstory.ui.main

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.efrivahmi.neighborstory.R
import com.efrivahmi.neighborstory.databinding.ActivityMainBinding
import com.efrivahmi.neighborstory.ui.add.AddNeighborActivity
import com.efrivahmi.neighborstory.ui.welcome.WelcomeNeighborActivity
import com.efrivahmi.neighborstory.utils.NeighborFactory
import com.efrivahmi.neighborstory.utils.NeighborListAdapter

@Suppress("UNUSED_EXPRESSION")
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var rvNeighbor: RecyclerView
    private lateinit var factory: NeighborFactory
    private val mainViewModel: MainViewModel by viewModels { factory }
    private var token = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        factory = NeighborFactory.getInstance(this)

        val layoutManager = LinearLayoutManager(this)
        binding.rvNeighbor.layoutManager = layoutManager
        val itemDecoration = DividerItemDecoration(this, layoutManager.orientation)
        binding.rvNeighbor.addItemDecoration(itemDecoration)

        rvNeighbor = findViewById(R.id.rv_neighbor)
        binding.rvNeighbor.setHasFixedSize(true)

        ourAdapter()
        createSetup()
        isLogin()

    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return try {
            when (item.itemId) {
                R.id.menu_language -> {
                    startActivity(Intent(Settings.ACTION_LOCALE_SETTINGS))
                    true
                }
                R.id.menu_logout -> {
                    mainViewModel.neighborLogout()
                    true
                }
                else -> super.onOptionsItemSelected(item)
            }
        } catch (e: Exception) {
            false
        }
    }

    private fun isLogin() {
        showLoading(true)
        mainViewModel.getNeighbor().observe(this@MainActivity) {
            token = it.token
            if (!it.isLogin) {
                moveActivity()
            } else {
                showLoading(false)
                mainViewModel.createStory(token)
            }
        }
    }

    private fun ourAdapter() {
        mainViewModel.listNeighbor.observe(this) { adapter ->
            try {
                if (adapter != null) {
                    binding.rvNeighbor.adapter =  NeighborListAdapter(adapter.listStory)
                }
            } catch (e: Exception) {
                Log.e("MainActivity", "Error setting adapter", e)
                Toast.makeText(this, "Error setting adapter", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun createSetup() {
        binding.createStory.setOnClickListener {
            startActivity(Intent(this, AddNeighborActivity::class.java))
        }
    }

    private fun showLoading(isLoading: Boolean) {
        if (isLoading) {
            binding.progressBar3.visibility = View.VISIBLE
        } else {
            binding.progressBar3.visibility = View.GONE
        }
    }

    private fun moveActivity() {
        startActivity(Intent(this@MainActivity, WelcomeNeighborActivity::class.java))
        finish()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        val inflater = menuInflater
        inflater.inflate(R.menu.menu_first, menu)
        return true
    }

    override fun onBackPressed() {
        super.onBackPressed()
        finishAffinity()
    }
}