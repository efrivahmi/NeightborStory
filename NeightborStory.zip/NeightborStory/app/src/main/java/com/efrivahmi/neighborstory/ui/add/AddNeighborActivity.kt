package com.efrivahmi.neighborstory.ui.add

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.efrivahmi.neighborstory.databinding.ActivityAddNeighborBinding
import com.efrivahmi.neighborstory.ui.main.MainActivity
import com.efrivahmi.neighborstory.utils.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.File

@Suppress("NAME_SHADOWING")
class AddNeighborActivity : AppCompatActivity() {
    private lateinit var binding: ActivityAddNeighborBinding
    private lateinit var factory: NeighborFactory
    private val addViewModel: AddViewModel by viewModels { factory }
    private var getNeighborNew: File? = null

    companion object {
        private val REQUIRED_PERMISSIONS = arrayOf(Manifest.permission.CAMERA)
        private const val REQUEST_CODE_PERMISSIONS = 10
    }

    private val launcherIntentCamera = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            val myFile = File(currentPhotoPath)
            getNeighborNew = myFile
            val result = rotateBitmapFromExif(this, Uri.fromFile(getNeighborNew))
            Toast.makeText(applicationContext, "Image taken successfully", Toast.LENGTH_SHORT).show()
            binding.uploadImage.setImageBitmap(result)
        }
    }

    private val launcherIntentGallery = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            val selectedImg: Uri = result.data?.data as Uri
            val myFile = uriToNewFile(selectedImg, this)
            getNeighborNew = myFile
            binding.uploadImage.setImageURI(selectedImg)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddNeighborBinding.inflate(layoutInflater)
        setContentView(binding.root)
        factory = NeighborFactory.getInstance(this)

        if (!allPermissionsGranted()) {
            ActivityCompat.requestPermissions(
                this,
                REQUIRED_PERMISSIONS,
                REQUEST_CODE_PERMISSIONS
            )
        }

        binding.camera.setOnClickListener { startTakePhoto() }
        binding.gallery.setOnClickListener { startGallery() }
        binding.upload.setOnClickListener { uploadImage() }

        showLoading()
    }

    @SuppressLint("QueryPermissionsNeeded")
    private fun startTakePhoto() {
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        intent.resolveActivity(packageManager)

        createNewFile(application).also {
            val photoURI: Uri = FileProvider.getUriForFile(
                this,
                "com.efrivahmi.neighborstory",
                it
            )
            currentPhotoPath = it.absolutePath
            intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI)
            launcherIntentCamera.launch(intent)
        }
    }

    private fun startGallery() {
        val intent = Intent()
        intent.action = Intent.ACTION_GET_CONTENT
        intent.type = "image/*"
        val chooser = Intent.createChooser(intent, "Choose a Picture")
        launcherIntentGallery.launch(chooser)
    }

    private lateinit var currentPhotoPath: String

    private fun uploadImage() {
        addViewModel.getNeighbor().observe(this) { neighbor ->
            if (getNeighborNew != null) {
                val file = reduceImage(getNeighborNew as File)
                val requestImageFile = file.asRequestBody("image/jpeg".toMediaType())
                val imageMultipart = MultipartBody.Part.createFormData(
                    "photo",
                    file.name,
                    requestImageFile
                )
                uploadResponse(
                    neighbor.token,
                    imageMultipart,
                    binding.description.text.toString().toRequestBody("text/plain".toMediaType())
                )
            } else if (!toastDisplayed) {
                Toast.makeText(applicationContext, "Input Image First", Toast.LENGTH_SHORT).show()
                toastDisplayed = true
            }
        }
    }

    private var toastDisplayed = false

    private fun uploadResponse(
        token: String,
        file: MultipartBody.Part,
        description: RequestBody
    ) {
        addViewModel.uploadStory(token, file, description)
        addViewModel.upload.observe(this) {
            if (!it.error) {
                val intent = Intent(this, MainActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK
                startActivity(intent)
                finish()
            }
        }
        showToast()
    }

    private fun allPermissionsGranted() = REQUIRED_PERMISSIONS.all {
        ContextCompat.checkSelfPermission(
            baseContext, it
        ) == PackageManager.PERMISSION_GRANTED
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_CODE_PERMISSIONS) {
            if (allPermissionsGranted()) {
                Toast.makeText(
                    applicationContext,
                    "Camera permission granted",
                    Toast.LENGTH_SHORT
                ).show()
            } else {
                Toast.makeText(
                    applicationContext,
                    "Permissions not granted by the user.",
                    Toast.LENGTH_SHORT
                ).show()
                finish()
            }
        }
    }

    private fun showLoading() {
        addViewModel.isLoading.observe(this) {
            binding.progressBar5.visibility = if (it) View.VISIBLE else View.GONE
        }
    }

    private fun showToast() {
        addViewModel.toast.observe(this) {
            it.getContentIfNotHandled()?.let { toastText ->
                Toast.makeText(
                    this, toastText, Toast.LENGTH_SHORT
                ).show()
            }
        }
    }
}