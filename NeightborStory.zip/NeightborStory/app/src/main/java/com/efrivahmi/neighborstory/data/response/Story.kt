package com.efrivahmi.neighborstory.data.response

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class Story(
    val listStory: List<ListStoryItem>,
    val error: Boolean,
    val message: String
): Parcelable

@Parcelize
data class ListStoryItem(
    val photoUrl: String,
    val createdAt: String,
    val name: String,
    val description: String,
    val lon: Double,
    val lat: Double,
    val id: String
): Parcelable

