package com.efrivahmi.neighborstory.data.repository

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.asLiveData
import com.efrivahmi.neighborstory.data.api.ConfigApi
import com.efrivahmi.neighborstory.data.model.NeighborModel
import com.efrivahmi.neighborstory.data.response.AddStory
import com.efrivahmi.neighborstory.data.response.Login
import com.efrivahmi.neighborstory.data.response.Register
import com.efrivahmi.neighborstory.data.response.Story
import com.efrivahmi.neighborstory.local.NeighborPreference
import com.efrivahmi.neighborstory.utils.HelperToast
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class SourceData private constructor(
    private val pref: NeighborPreference,
    private val apiService: ConfigApi
) {

    companion object {
        private const val TAG = "SourceData"
        @Volatile private var instance: SourceData? = null
        fun getInstance(preferences: NeighborPreference, apiService: ConfigApi): SourceData =
            instance ?: synchronized(this) {
                instance ?: SourceData(preferences, apiService).also { instance = it }
            }
    }

    private val _register = MutableLiveData<Register>()
    val register: LiveData<Register> = _register

    private val _login = MutableLiveData<Login>()
    val login: LiveData<Login> = _login

    private val _createNew = MutableLiveData<AddStory>()
    val createNew: LiveData<AddStory> = _createNew

    private val _list = MutableLiveData<Story>()
    val list: LiveData<Story> = _list

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading

    private val _toastText = MutableLiveData<HelperToast<String>>()
    val toastText: LiveData<HelperToast<String>> = _toastText

    fun uploadRegister(name: String, email: String, password: String) {
        _isLoading.value = true
        apiService.neighborRegister(name, email, password)
            .enqueue(object : Callback<Register> {
                override fun onResponse(call: Call<Register>, response: Response<Register>) {
                    _isLoading.value = false
                    if (response.isSuccessful && response.body() != null) {
                        _register.value = response.body()
                        _toastText.value = HelperToast(response.body()?.message.toString())
                    } else {
                        _toastText.value = HelperToast(response.message().toString())
                        Log.e(TAG, "on Failure!: ${response.message()}, ${response.body()?.message.toString()}")
                    }
                }

                override fun onFailure(call: Call<Register>, t: Throwable) {
                    _isLoading.value = false
                    _toastText.value = HelperToast(t.message.toString())
                    Log.e(TAG, "Failed Register: ${t.message.toString()}")
                }
            })
    }

    fun uploadLogin(email: String, password: String) {
        _isLoading.value = true
        apiService.neighborLogin(email, password)
            .enqueue(object : Callback<Login> {
                override fun onResponse(call: Call<Login>, response: Response<Login>) {
                    _isLoading.value = false
                    if (response.isSuccessful && response.body() != null) {
                        _login.value = response.body()
                        _toastText.value = HelperToast(response.body()?.message.toString())
                    } else {
                        _toastText.value = HelperToast(response.message().toString())
                        Log.e(TAG, "on Failure!: ${response.message()}, ${response.body()?.message.toString()}")
                    }
                }

                override fun onFailure(call: Call<Login>, t: Throwable) {
                    _isLoading.value = false
                    _toastText.value = HelperToast(t.message.toString())
                    Log.e(TAG, "Failed Login: ${t.message.toString()}")
                }
            })
    }

    fun writeStory(token: String) {
        _isLoading.value = true
        apiService.storyNeighbor(token)
            .enqueue(object : Callback<Story> {
                override fun onResponse(call: Call<Story>, response: Response<Story>) {
                    _isLoading.value = false
                    if (response.isSuccessful && response.body() != null) {
                        _list.value = response.body()
                        _toastText.value = HelperToast(response.body()?.message.toString())
                    } else {
                        _toastText.value = HelperToast(response.message().toString())
                        Log.e(
                            TAG,
                            "on Failure!: ${response.message()}, ${response.body()?.message.toString()}"
                        )
                    }
                }
                override fun onFailure(call: Call<Story>, t: Throwable) {
                    _isLoading.value = false
                    _toastText.value = HelperToast(t.message.toString())
                    Log.e(TAG, "Error 404!: ${t.message.toString()}")
                }
            })
    }



    fun uploadNewStory(token: String, file: MultipartBody.Part, description: RequestBody) {
        _isLoading.value = true
        apiService.uploadDataNeighbor(token, file, description)
            .enqueue(object : Callback<AddStory> {
                override fun onResponse(call: Call<AddStory>, response: Response<AddStory>) {
                    _isLoading.value = false
                    if (response.isSuccessful && response.body() != null) {
                        _createNew.value = response.body()
                        _toastText.value = HelperToast(response.body()?.message.toString())
                    } else {
                        _toastText.value = HelperToast(response.message().toString())
                        Log.e(
                            TAG,
                            "on Failure!: ${response.message()}, ${response.body()?.message.toString()}")
                    }
                }

                override fun onFailure(call: Call<AddStory>, t: Throwable) {
                    _isLoading.value = false
                    _toastText.value = HelperToast(t.message.toString())
                    Log.e(TAG, "Failed Upload Story!: ${t.message.toString()}")
                }
            })
    }

    fun getNeighbor(): LiveData<NeighborModel> {
        return pref.getNeighborSession().asLiveData()
    }

    suspend fun saveUser(session: NeighborModel) {
        pref.saveNeighborSession(session)
    }

    suspend fun login() {
        pref.login()
    }

    suspend fun logout() {
        pref.logout()
    }
}