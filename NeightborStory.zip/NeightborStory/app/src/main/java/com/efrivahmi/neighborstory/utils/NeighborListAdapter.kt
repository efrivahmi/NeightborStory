package com.efrivahmi.neighborstory.utils

import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.efrivahmi.neighborstory.R
import com.efrivahmi.neighborstory.data.response.ListStoryItem
import com.efrivahmi.neighborstory.databinding.ItemNeighborBinding
import com.efrivahmi.neighborstory.ui.detail.DetailNeighborActivity

class NeighborListAdapter(private val listStory: List<ListStoryItem>) : RecyclerView.Adapter<NeighborListAdapter.ListViewHolder>() {

    inner class ListViewHolder(private var binding: ItemNeighborBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(userData: ListStoryItem) {
            binding.apply {
                if (userData.photoUrl.isNullOrEmpty()) {
                    ivStory.setImageResource(R.drawable.black)
                } else {
                    Glide.with(itemView.context)
                        .load(userData.photoUrl)
                        .into(ivStory)
                }
                tvTitle.text = userData.name ?: ""
                tvDesc.text = userData.description ?: ""
            }
            itemView.setOnClickListener {
                val intentToDetail = Intent(itemView.context, DetailNeighborActivity::class.java)
                intentToDetail.putExtra("DATA", userData)
                itemView.context.startActivity(intentToDetail)
            }
        }
    }

    override fun onCreateViewHolder(viewGroup: ViewGroup, i: Int): ListViewHolder {
        val binding = ItemNeighborBinding.inflate(LayoutInflater.from(viewGroup.context), viewGroup, false)
        return ListViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ListViewHolder, position: Int) {
        holder.bind(listStory[position])
    }

    override fun getItemCount() = listStory.size
}
