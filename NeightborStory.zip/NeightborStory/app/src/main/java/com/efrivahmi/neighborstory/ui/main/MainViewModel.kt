package com.efrivahmi.neighborstory.ui.main

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.efrivahmi.neighborstory.data.model.NeighborModel
import com.efrivahmi.neighborstory.data.repository.SourceData
import com.efrivahmi.neighborstory.data.response.Story
import kotlinx.coroutines.launch

class MainViewModel (private val sourceData: SourceData) : ViewModel() {
    val listNeighbor: LiveData<Story> = sourceData.list

    fun createStory(token: String) {
        viewModelScope.launch {
            sourceData.writeStory(token)
            Log.e("token", "onResponse: $token")
        }
    }

    fun getNeighbor(): LiveData<NeighborModel> {
        return sourceData.getNeighbor()
    }

    fun neighborLogout() {
        viewModelScope.launch {
            sourceData.logout()
        }
    }
}
